---
name: repo-map
description: 每次 session 開始先讀 REPO_INDEX.md（repo 地圖），讓 agent 一開始就知道整個 code base 的結構、關鍵檔案與「問題→目錄」對照表，不必從頭掃描。當使用者說「這個功能在哪」「這個 bug 在哪」「先了解這個 repo」「開始工作」「看一下專案結構」時使用；也用於地圖不存在或過時時重新產生／更新。
metadata:
  tags: repo-map, context, navigation, gx10, strata
  requires:
    bins: [python3, git]
  primaryEnv: REPO_MAP_URL
---

# repo-map

讓 agent 在 session 一開始就拿到整個 repo 的地圖，而不是靠一層層 grep 摸進去。

## 每次 session 開始必做

1. 找地圖檔（依序）：`REPO_INDEX.md` → `.repo-map/REPO_INDEX.md`
2. **找到 → 立刻讀它**，把「問題 → 目錄」對照表當成導航。
3. **沒找到 → 先產生**（見下），產完再讀。
4. 讀完再做任何工作。**不要先掃檔案。**

## 地圖怎麼用

`REPO_INDEX.md` 內容：

- 目錄樹（深度 2）＋ 每個檔案行數
- 符號索引（class / function → 檔案:行號），完整版在 `.repo-map/symbols.md`
- 入口點、TODO / FIXME、語言分布
- 每個頂層目錄一行摘要 ＋「常見問題 → 該看哪個目錄」對照表

**查東西的順序**：

1. 先看對照表 → 鎖定 1–2 個目錄
2. 再看符號索引 → 鎖定 1–2 個檔案
3. 只讀那幾個檔案

不要從頭到尾讀整個 repo，也不要在沒看地圖的情況下連續呼叫 `grep` 摸索。

## 地圖什麼時候過時

`REPO_INDEX.md` 開頭有 `generated at commit <sha>`。

- 若目前 `git rev-parse HEAD` 的 sha 跟地圖標的不同 → 地圖過時
- 過時就更新（只重做有變動的目錄，很快）：

```bash
python3 <skill-dir>/scripts/repo-map.py --refresh
```

## 產生／更新地圖

```bash
python3 <skill-dir>/scripts/repo-map.py --init      # 第一次產生
python3 <skill-dir>/scripts/repo-map.py --refresh   # 只更新有變動的目錄
python3 <skill-dir>/scripts/repo-map.py --stats     # 看目前狀態
python3 <skill-dir>/scripts/repo-map.py --no-model  # 只產骨架（不呼叫模型）
```

腳本分兩層：

1. **骨架層（純腳本，不用模型，零失真）** — 目錄樹、行數、符號索引、入口點、TODO、import 關係
2. **語意層（呼叫 Strata）** — 逐個頂層目錄產生「用途 / 關鍵檔案 / 資料流 / 常見問題」

模型端點（拿不到就自動降級成只有骨架，功能仍可用）：

| 環境變數 | 預設 |
|---|---|
| `REPO_MAP_URL` | `http://gx10-37a8:8080/v1` |
| `REPO_MAP_API_KEY` | 讀 `~/Strata/gx10-api-key.txt` |
| `REPO_MAP_MODEL` | `qwen3.8-flash-next-iq3_s` |

## 讓編輯器 agent 每個 session 自動載入

安裝時會在目標 repo 寫入 `.github/instructions/repo-map.instructions.md`（`applyTo: "**"`），
VS Code 的 Copilot Chat 每個 session 都會先讀到這段指示。

其他 agent：

- Codex CLI / VS Code → 把「每次 session 先讀 REPO_INDEX.md」那段加到 `AGENTS.md`
- Cline / Roo Code → 加到 `.clinerules` / `.roorules`

## 注意事項

- 地圖是**導航用**，不是原始碼的替代品。定位到目錄後一定要讀真正的檔案。
- 地圖由腳本產生，不會自己更新。改了程式碼要跑 `--refresh`。
- 若 repo 有 `REPO_INDEX.md` 以外的既有同名檔，先改名避免覆蓋（安裝腳本不會覆蓋既有檔）。
