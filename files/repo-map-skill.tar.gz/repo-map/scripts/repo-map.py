#!/usr/bin/env python3
"""repo-map.py — 產生／更新 repo 地圖（REPO_INDEX.md）

兩層：
  1. 骨架層（純腳本，不用模型，零失真）—— 目錄樹、行數、符號索引、入口點、TODO、import
  2. 語意層（呼叫 Strata）—— 每個頂層目錄的用途 / 關鍵檔案 / 資料流 / 常見問題

用法：
  python3 repo-map.py --init       第一次產生
  python3 repo-map.py --refresh    只更新有變動的目錄
  python3 repo-map.py --stats      看目前狀態（是否過時）
  python3 repo-map.py --no-model   只產骨架
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
    "env", "dist", "build", "target", "out", ".next", ".nuxt", ".cache",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "vendor", "site-packages",
    ".idea", ".vscode", ".tox", "coverage", ".repo-map", "models", "data",
}

SKIP_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".svgz",
    ".pdf", ".zip", ".gz", ".bz2", ".xz", ".tar", ".7z", ".rar",
    ".mp3", ".mp4", ".mov", ".avi", ".mkv", ".wav", ".flac", ".ogg",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".bin", ".safetensors", ".gguf", ".pt", ".pth", ".ckpt", ".onnx",
    ".npy", ".npz", ".so", ".dylib", ".dll", ".exe", ".class", ".jar",
    ".wasm", ".db", ".sqlite", ".parquet",
}

MAX_FILE_BYTES = 512 * 1024
MAX_SYMBOLS_PER_DIR = 120
MAX_SYMBOLS_IN_INDEX = 400
MAX_TODOS = 40

SYMBOL_RULES = [
    ("class", re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?(?:final\s+)?class\s+([A-Za-z_]\w*)")),
    ("interface", re.compile(r"^\s*(?:export\s+)?interface\s+([A-Za-z_]\w*)")),
    ("struct", re.compile(r"^\s*(?:export\s+)?(?:type\s+)?([A-Za-z_]\w*)\s+struct\s*\{")),
    ("def", re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?def\s+([A-Za-z_]\w*)")),
    ("fn", re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_]\w*)")),
    ("fn", re.compile(r"^\s*(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)")),
    ("fn", re.compile(r"^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_]\w*)\s*=\s*(?:async\s*)?\(")),
    ("method", re.compile(r"^\s*(?:public\s+|private\s+|protected\s+|static\s+|async\s+)*([A-Za-z_]\w*)\s*\([^;]*\)\s*[:{]\s*$")),
]

NOT_SYMBOLS = {
    "if", "elif", "else", "for", "while", "switch", "case", "catch", "except",
    "return", "do", "try", "finally", "with", "match", "when", "and", "or",
    "not", "in", "is", "assert", "print", "super", "self", "constructor",
}

ENTRY_NAMES = {
    "main.py", "__main__.py", "app.py", "cli.py", "server.py", "run.py",
    "main.go", "main.rs", "main.ts", "index.js", "index.ts", "app.ts",
    "program.cs",
}

ROOT_MARKERS = {
    "package.json", "pyproject.toml", "setup.py", "Cargo.toml", "go.mod",
    "Makefile", "docker-compose.yml", "Dockerfile",
}

TODO_RE = re.compile(r"\b(TODO|FIXME|XXX|HACK)\b[:：]?\s*(.{0,80})")
IMPORT_RE = re.compile(r"^\s*(?:import\s|from\s|use\s|require\(|import\(|#include\s|using\s)")

LANG_BY_EXT = {
    ".py": "Python", ".ts": "TypeScript", ".tsx": "TypeScript", ".js": "JavaScript",
    ".jsx": "JavaScript", ".go": "Go", ".rs": "Rust", ".java": "Java",
    ".cs": "C#", ".c": "C", ".cpp": "C++", ".h": "C/C++", ".rb": "Ruby",
    ".php": "PHP", ".swift": "Swift", ".kt": "Kotlin", ".scala": "Scala",
    ".sh": "Shell", ".bash": "Shell", ".zsh": "Shell", ".ps1": "PowerShell",
    ".sql": "SQL", ".yaml": "YAML", ".yml": "YAML", ".toml": "TOML",
    ".json": "JSON", ".md": "Markdown", ".html": "HTML", ".css": "CSS",
    ".vue": "Vue", ".svelte": "Svelte", ".lua": "Lua", ".r": "R",
    ".dart": "Dart", ".ex": "Elixir", ".exs": "Elixir", ".hs": "Haskell",
}


def say(msg: str) -> None:
    print(msg, flush=True)


def git_commit(root: pathlib.Path) -> str:
    try:
        out = subprocess.run(["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                             capture_output=True, text=True, timeout=10)
        if out.returncode == 0:
            return out.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return "no-git"


def slugify(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-") or "root"
    return cleaned.lower()


def scan(root: pathlib.Path):
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames
                             if d not in SKIP_DIRS and not d.startswith("."))
        for name in sorted(filenames):
            if name.startswith("."):
                continue
            path = pathlib.Path(dirpath) / name
            ext = path.suffix.lower()
            if ext in SKIP_EXTS:
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size > MAX_FILE_BYTES:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            rel = path.relative_to(root).as_posix()
            lines = text.splitlines()
            symbols = []
            for number, line in enumerate(lines, start=1):
                if len(line) > 300:
                    continue
                for kind, rule in SYMBOL_RULES:
                    match = rule.match(line)
                    if match and match.group(1) not in NOT_SYMBOLS:
                        symbols.append((kind, match.group(1), number))
                        break
            todos = []
            for number, line in enumerate(lines, start=1):
                match = TODO_RE.search(line)
                if match:
                    todos.append((number, match.group(1), match.group(2).strip()))
            imports = []
            for line in lines[:80]:
                if IMPORT_RE.match(line):
                    imports.append(line.strip()[:100])
                if len(imports) >= 4:
                    break
            is_entry = name in ENTRY_NAMES or "__main__" in text
            files.append({
                "rel": rel,
                "name": name,
                "dir": str(pathlib.PurePosixPath(rel).parent),
                "ext": ext,
                "lang": LANG_BY_EXT.get(ext, ext.lstrip(".") or "其他"),
                "size": size,
                "lines": len(lines),
                "symbols": symbols,
                "todos": todos,
                "imports": imports,
                "is_entry": is_entry,
                "is_marker": name in ROOT_MARKERS,
            })
    return files


def group_of(rel: str) -> str:
    parts = pathlib.PurePosixPath(rel).parts
    return parts[0] if len(parts) > 1 else "(根目錄)"


def digest_of(files) -> str:
    hasher = hashlib.sha1()
    for item in sorted(files, key=lambda f: f["rel"]):
        names = ",".join(sorted(s[1] for s in item["symbols"]))
        hasher.update(("%s|%d|%s\n" % (item["rel"], item["size"], names)).encode())
    return hasher.hexdigest()[:16]


def load_key(explicit: str) -> str:
    if explicit:
        return explicit.strip()
    env = os.environ.get("REPO_MAP_API_KEY", "").strip()
    if env:
        return env
    for candidate in (pathlib.Path.home() / "Strata" / "gx10-api-key.txt",
                      pathlib.Path.home() / "gx10-api-key.txt"):
        try:
            if candidate.is_file():
                value = candidate.read_text(encoding="utf-8").strip()
                if value:
                    return value
        except OSError:
            continue
    return ""


def call_model(base_url: str, api_key: str, model: str, prompt: str,
                timeout: int = 240) -> str:
    url = base_url.rstrip("/") + "/chat/completions"
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 700,
        "temperature": 0.1,
        "reasoning_effort": "none",
    }
    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    request = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
    except (urllib.error.URLError, OSError, ValueError) as exc:
        say("  ! 模型呼叫失敗：%s" % exc)
        return ""
    choices = data.get("choices") or []
    if not choices:
        return ""
    return (choices[0].get("message") or {}).get("content") or ""


def build_prompt(group: str, files) -> str:
    listing = "\n".join(
        "  %-44s %6d 行" % (item["rel"], item["lines"]) for item in files[:120])
    symbols = []
    for item in files:
        for kind, name, number in item["symbols"]:
            symbols.append("  %-8s %-32s %s:%d" % (kind, name, item["rel"], number))
            if len(symbols) >= MAX_SYMBOLS_PER_DIR:
                break
        if len(symbols) >= MAX_SYMBOLS_PER_DIR:
            break
    symbol_text = "\n".join(symbols) if symbols else "  （沒有偵測到符號）"
    todos = []
    for item in files:
        for number, tag, note in item["todos"][:2]:
            todos.append("  %s:%d %s %s" % (item["rel"], number, tag, note))
            if len(todos) >= 12:
                break
        if len(todos) >= 12:
            break
    todo_text = "\n".join(todos) if todos else "  （無）"
    return (
        "你正在幫一個程式碼庫建立導航地圖。以下是某個目錄的資訊。\n\n"
        "目錄：%s\n\n"
        "檔案清單（共 %d 個）：\n%s\n\n"
        "符號索引：\n%s\n\n"
        "待辦標記：\n%s\n\n"
        "請只輸出下面這個格式的 Markdown，不要任何前言或解釋：\n\n"
        "### %s\n"
        "**用途**：一句話說明這個目錄負責什麼\n"
        "**關鍵檔案**：\n"
        "- `檔名` — 一句話說明它做什麼（列 2–4 個）\n"
        "**資料流**：一行，說明資料從哪來到哪去；沒有就寫「無明顯資料流」\n"
        "**常見問題**：列 2–3 個「使用者會問的問題 → 該看哪個檔案」\n"
        % (group, len(files), listing, symbol_text, todo_text, group)
    )


def summarize_group(group: str, files, base_url: str, api_key: str,
                    model: str) -> str:
    text = call_model(base_url, api_key, model, build_prompt(group, files))
    if not text.strip():
        return ""
    text = re.sub(r"^```[a-zA-Z]*\n", "", text.strip())
    text = re.sub(r"\n```\s*$", "", text)
    if not text.lstrip().startswith("###"):
        text = "### %s\n%s" % (group, text)
    return text.strip()


def summary_line(text: str, fallback: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("**用途**"):
            value = stripped.replace("**用途**", "").lstrip("：: ").strip()
            if value:
                return value[:90]
    return fallback


def key_files_line(text: str, files) -> str:
    names = []
    for line in text.splitlines():
        match = re.match(r"^\s*-\s*`([^`]+)`", line)
        if match:
            names.append(match.group(1))
        if len(names) >= 3:
            break
    if not names:
        names = [item["name"] for item in files[:3]]
    return ", ".join("`%s`" % n for n in names)


def render_index(root, files, groups, summaries, commit, model_name):
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    total_lines = sum(item["lines"] for item in files)
    langs = {}
    for item in files:
        langs[item["lang"]] = langs.get(item["lang"], 0) + 1
    lang_text = "、".join("%s %d" % (name, count)
                          for name, count in sorted(langs.items(), key=lambda kv: -kv[1])[:8])

    out = []
    out.append("# Repo 地圖：%s" % root.name)
    out.append("")
    out.append("> generated at commit `%s` ｜ %s ｜ 語意層：%s"
               % (commit, now, model_name or "無（只有骨架）"))
    out.append("> 完整符號索引見 `.repo-map/symbols.md`；各目錄詳解見 `.repo-map/dirs/`")
    out.append("")
    out.append("## 快速導航")
    out.append("")
    out.append("| 目錄 | 用途 | 關鍵檔案 |")
    out.append("|---|---|---|")
    for group in sorted(groups):
        files_in_group = groups[group]
        summary = summaries.get(group, "")
        purpose = summary_line(summary, "%d 個檔案、%d 行" % (
            len(files_in_group), sum(f["lines"] for f in files_in_group)))
        out.append("| `%s/` | %s | %s |" % (group, purpose, key_files_line(summary, files_in_group)))
    out.append("")

    out.append("## 統計")
    out.append("")
    out.append("- 檔案數：%d　總行數：%s" % (len(files), format(total_lines, ",")))
    out.append("- 語言分布：%s" % (lang_text or "—"))
    out.append("- 頂層分組：%d" % len(groups))
    out.append("")

    entries = [item for item in files if item["is_entry"]]
    if entries:
        out.append("## 入口點")
        out.append("")
        for item in entries[:25]:
            out.append("- `%s`（%d 行）" % (item["rel"], item["lines"]))
        out.append("")

    markers = [item for item in files if item["is_marker"]]
    if markers:
        out.append("## 專案根檔")
        out.append("")
        for item in markers[:15]:
            out.append("- `%s`" % item["rel"])
        out.append("")

    all_todos = []
    for item in files:
        for number, tag, note in item["todos"]:
            all_todos.append((item["rel"], number, tag, note))
    if all_todos:
        out.append("## TODO / FIXME")
        out.append("")
        for rel, number, tag, note in all_todos[:MAX_TODOS]:
            text = (tag + " " + note).strip()
            out.append("- `%s:%d` — %s" % (rel, number, text[:110]))
        out.append("")

    out.append("## 符號索引（摘要）")
    out.append("")
    rows = []
    for item in files:
        for kind, name, number in item["symbols"]:
            rows.append((kind, name, item["rel"], number))
    for kind, name, rel, number in rows[:MAX_SYMBOLS_IN_INDEX]:
        out.append("- `%s` **%s** → `%s:%d`" % (kind, name, rel, number))
    if len(rows) > MAX_SYMBOLS_IN_INDEX:
        out.append("")
        out.append("> 還有 %d 筆，完整版在 `.repo-map/symbols.md`" % (len(rows) - MAX_SYMBOLS_IN_INDEX))
    out.append("")

    out.append("## 目錄樹（深度 2）")
    out.append("")
    tree = {}
    for item in files:
        parts = pathlib.PurePosixPath(item["rel"]).parts
        if len(parts) == 1:
            tree.setdefault(".", []).append(item)
        else:
            tree.setdefault(parts[0], []).append(item)
    for name in sorted(tree):
        if name == ".":
            for item in sorted(tree[name], key=lambda f: f["rel"]):
                out.append("- `%s`（%d 行）" % (item["rel"], item["lines"]))
            continue
        group_files = tree[name]
        out.append("- `%s/`（%d 個檔案）" % (name, len(group_files)))
        for item in sorted(group_files, key=lambda f: f["rel"])[:12]:
            out.append("  - `%s`（%d 行）" % (item["rel"], item["lines"]))
        if len(group_files) > 12:
            out.append("  - …還有 %d 個" % (len(group_files) - 12))
    out.append("")
    return "\n".join(out)


def render_symbols(files):
    rows = []
    for item in files:
        for kind, name, number in item["symbols"]:
            rows.append((kind, name, item["rel"], number))
    lines = ["# 完整符號索引（%d 筆）" % len(rows), ""]
    for kind, name, rel, number in rows:
        lines.append("- `%s` **%s** → `%s:%d`" % (kind, name, rel, number))
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="產生／更新 repo 地圖")
    parser.add_argument("--dir", default=".", help="repo 根目錄")
    parser.add_argument("--init", action="store_true", help="完整產生")
    parser.add_argument("--refresh", action="store_true", help="只更新有變動的目錄")
    parser.add_argument("--stats", action="store_true", help="看狀態")
    parser.add_argument("--no-model", action="store_true", help="不呼叫模型，只產骨架")
    parser.add_argument("--url", default=os.environ.get("REPO_MAP_URL", "http://gx10-37a8:8080/v1"))
    parser.add_argument("--api-key", default="")
    parser.add_argument("--model", default=os.environ.get("REPO_MAP_MODEL", "qwen3.8-flash-next-iq3_s"))
    args = parser.parse_args()

    root = pathlib.Path(args.dir).expanduser().resolve()
    if not root.is_dir():
        say("找不到目錄：%s" % root)
        return 2
    outdir = root / ".repo-map"
    dirsdir = outdir / "dirs"
    state_path = outdir / "state.json"
    index_path = root / "REPO_INDEX.md"

    commit = git_commit(root)
    say("repo：%s（commit %s）" % (root, commit))

    state = {}
    if state_path.is_file():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            state = {}

    if args.stats:
        say("地圖：%s" % ("有" if index_path.is_file() else "沒有"))
        say("commit：%s（地圖記錄 %s）%s"
            % (commit, state.get("commit", "—"),
               "→ 已過時" if state.get("commit") and state["commit"] != commit else "→ 最新"))
        for group, info in sorted((state.get("groups") or {}).items()):
            say("  %-28s %s" % (group, info.get("digest", "?")))
        return 0

    say("掃描檔案…")
    files = scan(root)
    say("  %d 個檔案" % len(files))

    groups = {}
    for item in files:
        groups.setdefault(group_of(item["rel"]), []).append(item)

    digests = {group: digest_of(items) for group, items in groups.items()}
    old_groups = state.get("groups") or {}

    if args.refresh:
        changed = [g for g, d in digests.items() if old_groups.get(g, {}).get("digest") != d]
        say("有變動的目錄：%d" % len(changed))
    else:
        changed = sorted(groups)

    summaries = {}
    for group, info in (old_groups or {}).items():
        path = dirsdir / ("%s.md" % info.get("slug", slugify(group)))
        if path.is_file():
            try:
                summaries[group] = path.read_text(encoding="utf-8")
            except OSError:
                pass

    api_key = load_key(args.api_key)
    use_model = not args.no_model
    if use_model and not api_key:
        say("  ! 沒有金鑰，只產骨架（設定 REPO_MAP_API_KEY 或 ~/Strata/gx10-api-key.txt）")
        use_model = False

    model_name = ""
    if use_model:
        model_name = args.model
        for group in changed:
            say("產生語意摘要：%s" % group)
            text = summarize_group(group, groups[group], args.url, api_key, args.model)
            if text:
                summaries[group] = text
                dirsdir.mkdir(parents=True, exist_ok=True)
                (dirsdir / ("%s.md" % slugify(group))).write_text(text + "\n", encoding="utf-8")
            time.sleep(0.2)

    index_path.write_text(render_index(root, files, groups, summaries, commit, model_name),
                          encoding="utf-8")
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "symbols.md").write_text(render_symbols(files), encoding="utf-8")

    new_state = {"commit": commit, "updated": dt.datetime.now().isoformat(timespec="seconds"),
                 "groups": {}}
    for group, digest in digests.items():
        new_state["groups"][group] = {
            "digest": digest,
            "slug": slugify(group),
            "summary": (dirsdir / ("%s.md" % slugify(group))).is_file(),
        }
    state_path.write_text(json.dumps(new_state, indent=2, ensure_ascii=False), encoding="utf-8")

    say("")
    say("完成：%s" % index_path)
    say("     %s" % (outdir / "symbols.md"))
    say("     %s" % dirsdir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
