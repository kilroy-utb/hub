#!/usr/bin/env bash
# install.sh — 安裝 repo-map skill，並讓編輯器 agent 每個 session 先讀地圖
#
#   bash scripts/install.sh [目標repo路徑]
#
# 做四件事：
#   1. 把 skill 複製到 ~/.hermes/skills、~/.codex/skills、/workspace/.codex/skills
#   2. 在目標 repo 寫入 .github/instructions/repo-map.instructions.md（applyTo: "**"）
#      → VS Code Copilot Chat 每個 session 自動載入
#   3. 在目標 repo 的 AGENTS.md / .clinerules / .roorules 追加同一段指示（有就跳過，不覆蓋）
#   4. 產生第一次地圖（沒有模型金鑰也會產骨架）
set -euo pipefail

SKILL="repo-map"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$PWD}"
SKIP_MAP=0

while [ $# -gt 0 ]; do
  case "$1" in
    --no-map) SKIP_MAP=1; shift ;;
    --target) TARGET="$2"; shift 2 ;;
    *) shift ;;
  esac
done

say(){ printf '\033[36m==>\033[0m %s\n' "$*"; }
die(){ printf '\033[31m錯誤：\033[0m %s\n' "$*" >&2; exit 1; }
warn(){ printf '\033[33m[!!]\033[0m %s\n' "$*"; }

[ -f "$HERE/SKILL.md" ] || die "找不到 $HERE/SKILL.md"

# ── 1. 安裝 skill ───────────────────────────────────────────
say "安裝 skill 到各個 agent 目錄"
for dest in "$HOME/.hermes/skills" "$HOME/.codex/skills" "/workspace/.codex/skills"; do
  mkdir -p "$dest" 2>/dev/null || continue
  if [ -d "$dest/$SKILL" ] && [ "$(cd "$dest/$SKILL" && pwd -P)" = "$(cd "$HERE" && pwd -P)" ]; then
    echo "  = $dest/$SKILL（就是來源，略過）"
    continue
  fi
  mkdir -p "$dest/$SKILL"
  cp -r "$HERE/." "$dest/$SKILL/"
  chmod +x "$dest/$SKILL/scripts/"*.py "$dest/$SKILL/scripts/"*.sh 2>/dev/null || true
  echo "  + $dest/$SKILL"
done

# ── 2. VS Code 自動載入的指示檔 ─────────────────────────────
say "寫入 VS Code 自動載入指示（$TARGET）"
mkdir -p "$TARGET/.github/instructions"
cat > "$TARGET/.github/instructions/repo-map.instructions.md" <<'INSTRUCTEOF'
---
applyTo: "**"
---

# Repo 地圖（每個 session 必讀）

開始任何工作之前，先讀取 repo 根目錄的 `REPO_INDEX.md`（若不存在則讀 `.repo-map/REPO_INDEX.md`）。

- `REPO_INDEX.md` 有：快速導航表（問題 → 該看哪個目錄）、符號索引、入口點、TODO 清單。
- 定位方式：先看導航表鎖定 1–2 個目錄 → 再看符號索引鎖定 1–2 個檔案 → 只讀那些檔案。
- 不要從頭掃描整個 repo，也不要在沒看地圖的情況下連續 grep 摸索。
- 地圖開頭有 `generated at commit`；若與目前 HEAD 不同，先跑
  `python3 <skill-dir>/scripts/repo-map.py --refresh` 更新再開始工作。
- 地圖是導航用，不是原始碼的替代品；定位後一定要讀真正的檔案。
INSTRUCTEOF
echo "  + $TARGET/.github/instructions/repo-map.instructions.md"

# ── 3. 其他 agent 的指示檔（追加，不覆蓋）────────────────────
BLOCK_START="<!-- repo-map:begin -->"
BLOCK_END="<!-- repo-map:end -->"
BLOCK="Repo 地圖（每個 session 必讀）

開始任何工作前，先讀取 repo 根目錄的 \`REPO_INDEX.md\`（不存在則讀 \`.repo-map/REPO_INDEX.md\`）。
先用導航表鎖定 1–2 個目錄，再用符號索引鎖定 1–2 個檔案，只讀那些檔案；不要從頭掃描整個 repo。
地圖開頭的 commit 若與 HEAD 不同，先跑 \`python3 <skill-dir>/scripts/repo-map.py --refresh\`。"

add_block() {
  local file="$1"
  if [ -f "$file" ] && grep -qF "$BLOCK_START" "$file"; then
    echo "  = $file（已有區塊，略過）"
    return
  fi
  if [ -f "$file" ]; then
    printf '\n%s\n%s\n%s\n' "$BLOCK_START" "$BLOCK" "$BLOCK_END" >> "$file"
  else
    printf '%s\n%s\n%s\n' "$BLOCK_START" "$BLOCK" "$BLOCK_END" > "$file"
  fi
  echo "  + $file"
}

for name in AGENTS.md .clinerules .roorules; do
  add_block "$TARGET/$name"
done

# ── 4. 產生第一次地圖 ───────────────────────────────────────
if [ "$SKIP_MAP" = "1" ]; then
  say "略過地圖產生（--no-map）"
else
  say "產生地圖（$TARGET）"
  python3 "$HERE/scripts/repo-map.py" --dir "$TARGET" --init || warn "地圖產生失敗，可稍後手動跑"
fi

cat <<'DONEEOF'

完成。接下來：
  1. 開新的 agent session，它會先讀 REPO_INDEX.md
  2. 地圖過時時：python3 ~/.hermes/skills/repo-map/scripts/repo-map.py --refresh --dir <repo>
  3. 想確認狀態：python3 ~/.hermes/skills/repo-map/scripts/repo-map.py --stats --dir <repo>
DONEEOF
