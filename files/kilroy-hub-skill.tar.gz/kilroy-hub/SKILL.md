---
name: kilroy-hub
description: Push local files to the kilroy-utb/hub GitHub repo (a GitHub Pages hub with files/, wiki/, notes/, todo/) and pull them back. Use when the user says 「推到 hub」「更新 hub」「同步 hub 檔案」「發佈到 kilroy-utb」「抓最新腳本」, or asks to publish scripts to the hub repo, rebuild its file index, or verify GitHub Pages after a deploy. Also covers the GX10 × Strata tool bundle.
metadata:
  tags: [github, git, hub, deploy, github-pages, scripts, gx10]
  requires:
    bins: [git, curl, python3]
  primaryEnv: GITHUB_TOKEN
---

# Kilroy Hub

把檔案發佈到 `kilroy-utb/hub`，並維護它的 GitHub Pages 檔案清單頁。

## 目標 repo 的結構

```
kilroy-utb/hub  (public, GitHub Pages)
├── .github/workflows/hub-build.yml   ← push 到 main 會觸發，用 Actions 的
│                                       GITHUB_TOKEN 自動重產 index.html
├── .hermes/skills/hub/               ← repo 內附的 hub skill（hub.py build）
├── files/                            ← 這個 skill 主要管理的目錄
├── hub.yaml                          ← 首頁設定（section 定義）
├── wiki/gx10-strata/                  ← GX10 專區
├── notes/  todo/
└── index.html
```

Pages 網址：`https://kilroy-utb.github.io/hub/`（`files/` 在 `/hub/files/`）

## 新環境自我修復（agent 必讀）

第一次用、或 push 報認證錯時，**照這個順序查**，不要重頭猜：

**步驟 1 — skill 在不在？**

```bash
ls /workspace/.codex/skills/kilroy-hub/SKILL.md 2>/dev/null && echo "在，可直接用"
curl -s localhost:8080/get-skills | grep -o '"name":"kilroy-hub"'
```

**步驟 2 — 不在的話，從公開 Pages 裝（不需要任何憑證）**

```bash
curl -O https://kilroy-utb.github.io/hub/files/kilroy-hub-skill.sh
GITHUB_TOKEN=ghp_xxx bash kilroy-hub-skill.sh
```

這個 bootstrap 會下載 skill、把你給的 PAT 注入 `scripts/push_to_hub.sh`、裝到
`/workspace/.codex/skills/` 與 `~/.codex/skills/`。PAT 只寫在本機，不會進公開 repo。

**步驟 3 — 還是不行，改用私有 repo（需要憑證才能 clone）**

```bash
git clone https://github.com/kilroy-utb/agent-skills.git /tmp/skills
bash /tmp/skills/kilroy-hub/scripts/install.sh
```

私有 repo 裡的 PAT 是最新的，適合「公開 bootstrap 的 PAT 過期了」的情況。

**步驟 4 — 診斷訊息對照**

| 訊息 | 意義 | 處理 |
|---|---|---|
| `Could not read a skill named kilroy-hub` | skill 沒裝 | 走步驟 2 |
| `could not read Username for 'https://github.com'` | 沒有憑證 | 走步驟 2 或 3，帶 PAT |
| `Invalid username or token` | PAT 過期或無權限 | 走步驟 3（私有 repo 內有較新的 PAT） |
| `remote: Permission to kilroy-utb/hub.git denied` | PAT 無 `Contents:write` | 重發 PAT，權限選 `repo` 或 fine-grained 的 `Contents: Read and write` |
| `Permission denied (publickey)` | 走 SSH 但沒金鑰 | 本 skill 走 HTTPS，改用 HTTPS |

**步驟 5 — 驗證真的能推**

```bash
bash scripts/push_to_hub.sh --dry-run     # 會 clone 但不寫不推
```

---

## 兩支腳本

```bash
# 推：把 bundle/ 發佈上去 + 重建清單頁 + 驗證 Pages
bash scripts/push_to_hub.sh
bash scripts/push_to_hub.sh --bundle ~/myfiles --message "feat: add xxx"

# 拉：抓回遠端最新版本（以 repo 為準，含別處新增的檔案）
bash scripts/sync_from_hub.sh --dir ~/gx10-scripts --flatten
bash scripts/sync_from_hub.sh --list
```

## 憑證

`push_to_hub.sh` 內建 PAT（可用 `GITHUB_TOKEN` 覆寫），走 `GIT_ASKPASS`，
**token 不會出現在 argv 或 `ps` 輸出**。不需要 `~/.git-credentials`。

## 規則

1. **index 頁是 `hub.py` 產生的，不要手改** —— `files/index.html`、`wiki/*/index.html`
   由 repo 內的 `.hermes/skills/hub/scripts/hub.py` 產生。手動插入的卡片會被 Actions
   覆蓋掉，反而製造多餘的 commit。
   `檔案下載` section 的 `type: file`，只列非 `.md`／`.html` 的檔案，所以
   `README*.md` 不會出現在 `files/index.html`（但仍可直接下載）。
2. **不要覆蓋 `files/README.md` 和 `files/index.html`** —— 這兩個是 repo 既有的檔案，
   `push_to_hub.sh` 會自動略過；自己的文件請用不同檔名（例如 `README-gx10.md`）。
3. **推送前一定會 `git pull --rebase`** —— `hub-bot` 幾乎每次 push 都會在 main 補一筆
   commit，不 rebase 會被 non-fast-forward 擋掉。
4. **Pages 要等約 1 分鐘** —— 推完不會立刻 200，先看 API 確認檔案在，再驗 Pages。
5. **推完會多一筆 `hub-bot` 的 commit** —— 那是 Actions 用 `hub.py` 重產 index 頁，
   屬正常現象，也是 index 頁的唯一來源。
6. **PAT 不要外傳** —— 不要貼到公開 repo、issue 或 log。`kilroy-utb/*` 底下的 repo
   目前全是 public，所以這個 skill 只能放在私有位置（見「跨容器使用」）。

## 排錯

| 症狀 | 原因 | 解法 |
|---|---|---|
| `could not read Username for 'https://github.com'` | 沒憑證 | 確認 PAT 變數有值，或用內建的 |
| `Invalid username or token` | PAT 過期／無寫入權限 | 重發 PAT，權限要 `Contents: Read and write`（fine-grained）或 `repo`（classic） |
| push 被拒 `non-fast-forward` | 沒 rebase | 腳本已自動處理；手動時 `git pull --rebase origin main` |
| Pages 404 | 還在重建 | 等 1 分鐘；或查 Actions 狀態 |
| `Permission denied (publickey)` | 走 SSH 但沒金鑰 | 這個 skill 走 HTTPS，不用 SSH |

## 跨容器使用

這個 skill 內含 PAT，**只能放在私有位置**。私有來源：`kilroy-utb/agent-skills`（private）。

```bash
git clone https://github.com/kilroy-utb/agent-skills.git /tmp/skills
cp -r /tmp/skills/kilroy-hub ~/.codex/skills/
# 或直接跑內建的安裝腳本（會裝到平台目錄 + Codex CLI 目錄）
bash /tmp/skills/kilroy-hub/scripts/install.sh
```

裝完之後新 session 的 agent 就會看到 `$kilroy-hub`，直接說「推到 hub」就會啟動。
驗證：`curl -s localhost:8080/get-skills | grep kilroy-hub` 應該看得到 `user`。

想改 repo／分支：改 `scripts/push_to_hub.sh` 的 `REPO`／`BRANCH`，或用
`--repo`／`--branch` 參數覆寫。
