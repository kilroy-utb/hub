#!/usr/bin/env bash
# sync_from_hub.sh — 從 kilroy-utb/hub 把最新檔案抓回本機
#
#   bash sync_from_hub.sh                          # 抓到當前目錄
#   bash sync_from_hub.sh --dir ~/gx10-scripts --flatten
#   bash sync_from_hub.sh --list                   # 只看遠端有什麼
#
# 抓的是 repo 裡的權威版本（raw.githubusercontent），所以別處新增的檔案
# 也會被抓下來；已刪除的檔案會被清掉，覆寫前會備份到 .sync_backup/
set -uo pipefail
REPO="${REPO:-kilroy-utb/hub}"
BRANCH="${BRANCH:-main}"
API="https://api.github.com"
TOKEN="${GITHUB_TOKEN:-}"
RAW="https://raw.githubusercontent.com/${REPO}/${BRANCH}/files"

LIST=0
PASSTHRU=()
while [ $# -gt 0 ]; do
  case "$1" in
    --repo) REPO="$2"; shift 2;;
    --branch) BRANCH="$2"; shift 2;;
    --list) LIST=1; shift;;
    --dir|--prefix|--exclude|--keep-backups)
      PASSTHRU+=("$1" "$2"); shift 2;;
    --flatten|--dry-run|--prune|--yes)
      PASSTHRU+=("$1"); shift;;
    --help|-h) sed -n '2,12p' "$0"; exit 0;;
    *) PASSTHRU+=("$1"); shift;;   # 其他參數原樣轉交給 sync_github_files.sh
  esac
done

TMP="$(mktemp -d "${TMPDIR:-/tmp}/hubsync.XXXXXX")"
trap 'rm -rf -- "$TMP"' EXIT

echo "==> 抓取 sync_github_files.sh（$REPO@$BRANCH）"
if ! curl -fsSL -m 60 -o "$TMP/sync_github_files.sh" "$RAW/sync_github_files.sh"; then
  echo "錯誤：抓不到 sync_github_files.sh，請確認 repo 與分支" >&2
  exit 1
fi
chmod +x "$TMP/sync_github_files.sh"

if [ "$LIST" = 1 ]; then
  exec bash "$TMP/sync_github_files.sh" --repo "$REPO" --branch "$BRANCH" --list
fi

exec bash "$TMP/sync_github_files.sh" --repo "$REPO" --branch "$BRANCH" ${PASSTHRU+"${PASSTHRU[@]}"}
