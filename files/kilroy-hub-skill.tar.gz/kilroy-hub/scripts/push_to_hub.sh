#!/usr/bin/env bash
# push_to_hub.sh — 把 bundle/ 的檔案發佈到 kilroy-utb/hub，並重建檔案清單頁
#
#   bash push_to_hub.sh                     # 用預設 bundle/
#   bash push_to_hub.sh --bundle ~/myfiles   # 指定要推的檔案
#   bash push_to_hub.sh --wiki-bundle ~/docs # 額外推到 wiki/gx10-strata/
#   bash push_to_hub.sh --dry-run           # 只看會做什麼
#   bash push_to_hub.sh --message "..."     # 自訂 commit 訊息
#
# 環境變數：
#   GITHUB_TOKEN  覆寫內建的 PAT
#   GIT_USERNAME  git 登入帳號（預設 kilroy-utb）
#   REPO / BRANCH 目標 repo 與分支（預設 kilroy-utb/hub / main）
set -euo pipefail

# ── 內建憑證（此 repo 為私有用途；可用 GITHUB_TOKEN 覆寫）─────────────
PAT="${GITHUB_TOKEN:-}"
GIT_USERNAME="${GIT_USERNAME:-kilroy-utb}"
REPO="${REPO:-kilroy-utb/hub}"
BRANCH="${BRANCH:-main}"
GIT_NAME="${GIT_NAME:-kilroy}"
GIT_EMAIL="${GIT_EMAIL:-kilroy@users.noreply.github.com}"
MESSAGE="feat: update hub files bundle"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE="$HERE/../bundle"
SKILL_DIR="$(cd "$HERE/.." && pwd)"
WIKI_BUNDLE="$SKILL_DIR/wiki-bundle"
DRY=0; SKIP_PAGES=0

while [ $# -gt 0 ]; do
  case "$1" in
    --bundle) BUNDLE="$2"; shift 2;;
    --wiki-bundle) WIKI_BUNDLE="$2"; shift 2;;
    --repo) REPO="$2"; shift 2;;
    --branch) BRANCH="$2"; shift 2;;
    --message) MESSAGE="$2"; shift 2;;
    --dry-run) DRY=1; shift;;
    --skip-pages) SKIP_PAGES=1; shift;;
    -h|--help) sed -n '2,20p' "$0"; exit 0;;
    *) echo "未知選項：$1" >&2; exit 1;;
  esac
done
BUNDLE="$(cd "$BUNDLE" && pwd)"

say(){ printf '\033[36m==>\033[0m %s\n' "$*"; }
die(){ printf '\033[31m錯誤：\033[0m %s\n' "$*" >&2; exit 1; }
for b in git curl python3; do command -v "$b" >/dev/null 2>&1 || die "需要 $b"; done
[ -n "$PAT" ] || die "沒有 PAT：請設 GITHUB_TOKEN 或在腳本裡填 PAT"
[ -d "$BUNDLE" ] || die "bundle 目錄不存在：$BUNDLE"

WORK="$(mktemp -d "${TMPDIR:-/tmp}/hubpush.XXXXXX")"
cleanup(){ [ -n "${WORK:-}" ] && [ -d "$WORK" ] && rm -rf -- "$WORK"; }
trap cleanup EXIT

say "抓 repo：$REPO ($BRANCH)"
git clone -q --depth 1 -b "$BRANCH" "https://github.com/$REPO.git" "$WORK/hub"
cd "$WORK/hub"
mkdir -p files

say "放入 bundle 檔案：$BUNDLE"
COPIED=0
for f in "$BUNDLE"/*; do
  [ -f "$f" ] || continue
  base="$(basename "$f")"
  case "$base" in
    README.md|index.html)
      echo "  略過 $base（避免覆蓋 repo 既有檔案）"; continue;;
  esac
  cp -p "$f" "files/$base"
  case "$base" in *.sh) chmod +x "files/$base";; esac
  echo "  + files/$base"
  COPIED=$((COPIED+1))
done
[ "$COPIED" -gt 0 ] || die "bundle 沒有可推的檔案"

if [ -d "$WIKI_BUNDLE" ]; then
  WIKI_BUNDLE="$(cd "$WIKI_BUNDLE" && pwd)"
  say "放入 wiki 檔案：$WIKI_BUNDLE → wiki/gx10-strata/"
  mkdir -p wiki/gx10-strata
  WCOPIED=0
  for f in "$WIKI_BUNDLE"/*; do
    [ -f "$f" ] || continue
    base="$(basename "$f")"
    case "$base" in
      index.html) echo "  略過 $base（由 Actions 重產）"; continue;;
    esac
    cp -p "$f" "wiki/gx10-strata/$base"
    echo "  + wiki/gx10-strata/$base"
    WCOPIED=$((WCOPIED+1))
  done
  [ "$WCOPIED" -gt 0 ] || echo "  wiki bundle 沒有可推的檔案"
else
  echo "  沒有 wiki bundle（略過）"
fi

say "重建檔案清單頁"
# index 頁由 repo 自己的 hub.py 產生（唯一來源）：
#   - 推上去後 GitHub Actions 的 hub-bot 會自動重產並 commit
#   - 這裡能本地跑就本地跑，讓 Actions 推完不會再多一筆 diff
if [ -f .hermes/skills/hub/scripts/hub.py ]; then
  if python3 -c "import yaml" 2>/dev/null; then
    python3 .hermes/skills/hub/scripts/hub.py build --no-push --output ./index.html \
      || echo "  本地 hub.py 失敗，交給 Actions 處理"
  else
    echo "  沒有 pyyaml，跳過本地重建（Actions 端有裝，會自動重產）"
  fi
else
  echo "  repo 內沒有 hub.py，跳過（Actions 會處理）"
fi

if [ "$DRY" = 1 ]; then
  say "dry-run：顯示變更後結束"
  git status --porcelain
  exit 0
fi

git add files/ wiki/ 2>/dev/null || git add files/
say "commit"
if git diff --cached --quiet; then
  echo "  沒有變更可提交"
else
  git -c user.name="$GIT_NAME" -c user.email="$GIT_EMAIL" commit -m "$MESSAGE"
fi

say "同步遠端最新 $BRANCH（hub-bot 可能剛推過）"
git fetch --unshallow origin "$BRANCH" 2>/dev/null || true
git pull --rebase origin "$BRANCH" 2>/dev/null || {
  git rebase --abort 2>/dev/null || true
  die "同步遠端失敗，請重跑一次"
}

say "推送"
ASK="$WORK/.askpass.sh"
cat > "$ASK" <<ASKPASS_EOF
#!/bin/sh
case "\$1" in
  *[Uu]sername*) printf '%s\n' "$GIT_USERNAME" ;;
  *) printf '%s\n' "$PAT" ;;
esac
ASKPASS_EOF
chmod 700 "$ASK"
GIT_ASKPASS="$ASK" GIT_TERMINAL_PROMPT=0 \
  git push "https://github.com/$REPO.git" "HEAD:$BRANCH" \
  || die "推送失敗，請確認 PAT 對 $REPO 有 Contents:write 權限"

if [ "$SKIP_PAGES" = 0 ]; then
  say "驗證 GitHub Pages（可能要等 1 分鐘重建）"
  OWNER="${REPO%%/*}"; NAME="${REPO##*/}"
  for f in $(ls files | head -8); do
    code="$(curl -s -o /dev/null -w '%{http_code}' "https://${OWNER}.github.io/${NAME}/files/$f" || true)"
    printf '  %-26s HTTP %s\n' "$f" "$code"
  done
fi

cat <<TXT

完成。遠端最新 commit：
  $(git log -1 --format='%h %s')

在目標機器上同步：
  bash scripts/sync_from_hub.sh --dir ~/gx10-scripts --flatten

TXT
