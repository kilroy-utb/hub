#!/usr/bin/env bash
# install.sh — 把本 skill 安裝到各種 skill 目錄，讓新 session 的 agent 看得到
#
#   bash scripts/install.sh
#
# 會裝到：
#   /workspace/.codex/skills/   ← ChatArt 平台（runner 的 /get-skills 會掃這裡）
#   ~/.codex/skills/            ← Codex CLI 本機
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$HERE")"
NAME="$(basename "$SKILL_DIR")"
INSTALLED=0
for dest in /workspace/.codex/skills "$HOME/.codex/skills"; do
  [ -d "$(dirname "$dest")" ] || continue
  mkdir -p "$dest/$NAME"
  rm -rf "${dest:?}/$NAME"
  cp -r "$SKILL_DIR" "$dest/$NAME"
  chmod +x "$dest/$NAME"/scripts/*.sh 2>/dev/null || true
  echo "已安裝 → $dest/$NAME"
  INSTALLED=$((INSTALLED+1))
done
[ "$INSTALLED" -gt 0 ] || { echo "沒有可寫入的 skill 目錄" >&2; exit 1; }
echo "完成。$NAME 已就緒，新 session 說「推到 hub」即可觸發。"
