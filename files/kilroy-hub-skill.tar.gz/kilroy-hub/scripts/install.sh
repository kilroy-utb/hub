#!/usr/bin/env bash
# install.sh — 把本 skill 安裝到各種 skill 目錄，讓新 session 的 agent 看得到
#
#   bash scripts/install.sh
#
# 會裝到：
#   /workspace/.codex/skills/   ← ChatArt 平台（runner 的 /get-skills 會掃這裡）
#   ~/.codex/skills/            ← Codex CLI 本機
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$HERE/.." && pwd)"
NAME="$(basename "$SKILL_DIR")"
INSTALLED=0
SKIPPED=0
for dest in /workspace/.codex/skills "$HOME/.codex/skills"; do
  [ -d "$(dirname "$dest")" ] || continue
  target="$dest/$NAME"
  # 從安裝位置再跑一次時，target 就是來源自己 → 跳過，不然會把自己刪掉
  if [ -d "$target" ] && [ "$(cd "$target" && pwd)" = "$SKILL_DIR" ]; then
    echo "略過 $target（就是本 script 的來源，不用重裝）"
    SKIPPED=$((SKIPPED+1))
    continue
  fi
  mkdir -p "$target"
  # 逐一覆蓋，不用 rm -rf 整個目錄，避免誤刪
  cp -r "$SKILL_DIR/." "$target/"
  chmod +x "$target"/scripts/*.sh "$target"/bundle/*.sh 2>/dev/null || true
  echo "已安裝 → $target"
  INSTALLED=$((INSTALLED+1))
done
[ "$INSTALLED" -gt 0 ] || echo "沒有可寫入的 skill 目錄（略過 $SKIPPED 個）"
echo "完成。$NAME 已就緒，新 session 說「推到 hub」即可觸發。"
