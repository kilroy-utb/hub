#!/usr/bin/env bash
# build_dist.sh — 產生公開可下載的 skill 套件（不含憑證）
#
#   bash scripts/build_dist.sh
#
# 產出：bundle/kilroy-hub-skill.tar.gz
#   = 整份 skill 的副本，但 push_to_hub.sh 裡的 PAT 被清空
#     （PAT 由 bundle/kilroy-hub-skill.sh 在安裝時注入）
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$HERE")"
NAME="$(basename "$SKILL_DIR")"
OUT="$SKILL_DIR/bundle/$NAME-skill.tar.gz"

WORK="$(mktemp -d "${TMPDIR:-/tmp}/khdist.XXXXXX")"
trap 'rm -rf -- "$WORK"' EXIT

cp -r "$SKILL_DIR" "$WORK/$NAME"
rm -f "$WORK/$NAME/bundle/$NAME-skill.tar.gz"

python3 "$HERE/strip_pat.py" "$WORK/$NAME/scripts/push_to_hub.sh"

if grep -rE "ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}" "$WORK/$NAME" >/dev/null 2>&1; then
  echo "錯誤：套件裡還有 token" >&2
  grep -rlE "ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}" "$WORK/$NAME" >&2
  exit 1
fi
echo "  token 掃描：乾淨"

tar -czf "$OUT" -C "$WORK" "$NAME"
echo "  已產生：$OUT ($(stat -c%s "$OUT") bytes)"
