#!/usr/bin/env python3
"""strip_pat.py — 把 push_to_hub.sh 裡內建的 PAT 清空（產生公開套件用）"""
import re
import sys

path = sys.argv[1]
s = open(path, encoding="utf-8").read()
s, n = re.subn(r'^PAT="\$\{GITHUB_TOKEN:-[^}]*\}"',
                'PAT="${GITHUB_TOKEN:-}"', s, count=1, flags=re.M)
if n == 0:
    sys.exit("找不到 PAT= 那行，請檢查 push_to_hub.sh")
open(path, "w", encoding="utf-8").write(s)
print("  已清除內建 PAT（改由安裝時注入）")
